# Member2 Residuals

This folder contains the full physics-derived feature export for the turbojet complete dataset. See the project-level README.md for equations and integration instructions.

## Files
- residual_dataset.csv
- efficiency_features.csv
- overall_engine_features.csv
- physics_station_features.csv
- engine_health_features.csv
- residual_summary.csv
- physics_metadata.json
- README.md
